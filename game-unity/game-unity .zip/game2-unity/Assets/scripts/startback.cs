﻿using UnityEngine;
using System.Collections;

public class startback : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	public void SceneLoad (){ 
 		Application.LoadLevel ("start"); 
 	} 
	// Update is called once per frame
	void Update () {
	
	}
}
